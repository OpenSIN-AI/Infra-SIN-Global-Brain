# ONE-BRAIN — OCI install package

Extract and run:

    tar xzf brain-oci.tar.gz -C /tmp/brain-oci
    sudo bash /tmp/brain-oci/install.sh

Env overrides (all optional):
    BRAIN_WORKSPACE=/srv/global-brain
    BRAIN_DATA_DIR=/var/lib/brain
    BRAIN_HTTP_PORT=7070
    BRAIN_NATS_URL=nats://127.0.0.1:4222
    INSTALL_NATS=1          # set 0 to keep your own nats-server
    INSTALL_HNSW=1          # set 0 to skip native HNSW try
    SEED_AGENTS_MD=1        # set 0 to skip initial PRIORITY-canon seed

The installer writes a systemd unit (brain-core.service), a service user
`brain`, installs production deps with `npm ci`, optionally fetches
nats-server v2.10.22, starts the daemon and (by default) seeds the
PRIORITY -10..-4 canon from AGENTS.md.
